import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Registration } from 'src/app/Models/registration';
import { UserService } from 'src/app/services/user.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-edit-register-data',
  templateUrl: './edit-register-data.component.html',
  styleUrls: ['./edit-register-data.component.css']
})
export class EditRegisterDataComponent implements OnInit {

  all_data_of_specific_id:any=[];
  
  constructor(private _myservice:UserService,
    private route:ActivatedRoute,
    private router:Router,
  ) { 
     this.all_data_of_specific_id=this.router.getCurrentNavigation()?.extras.state?.["response"];

     this.registration_id=this.all_data_of_specific_id.registration_id;
     this.username=this.all_data_of_specific_id.username;
     this.password=this.all_data_of_specific_id.password;
     this.firstname=this.all_data_of_specific_id.firstname;
     this.lastname=this.all_data_of_specific_id.lastname;
     this.email=this.all_data_of_specific_id.email;
     this.phone=this.all_data_of_specific_id.phone;
  }

  registration_id: any;
  username: any;
  password: any
  firstname: any
  lastname: any
  email: any
  phone: any

  regis_id:any;
  ngOnInit(): void {

 }

 registrationModel:any;
 msg:any

 allData:any;

 updateBy_spacific_id(){
  this.allData=new Registration(
    this.registration_id,
    this.username,
    this.password,
    this.firstname,
    this.lastname,
    this.email,
    this.phone
  );

  this._myservice.updateRegistration(this.allData).subscribe(()=>{

  })
 }


  //  end of class
  }



  


