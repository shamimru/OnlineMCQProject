import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EditRegisterDataComponent } from './edit-register-data.component';

describe('EditRegisterDataComponent', () => {
  let component: EditRegisterDataComponent;
  let fixture: ComponentFixture<EditRegisterDataComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EditRegisterDataComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(EditRegisterDataComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
