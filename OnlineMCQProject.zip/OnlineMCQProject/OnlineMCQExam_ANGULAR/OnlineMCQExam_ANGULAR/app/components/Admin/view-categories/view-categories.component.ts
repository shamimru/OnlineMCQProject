import { Component, OnInit } from '@angular/core';
import { CategorySeviceService } from 'src/app/services/category-sevice.service';
import Swal from 'sweetalert2'
@Component({
  selector: 'app-view-categories',
  templateUrl: './view-categories.component.html',
  styleUrls: ['./view-categories.component.css']
})
export class ViewCategoriesComponent implements OnInit {

  constructor(private _categories:CategorySeviceService) { }

  description:any;
  ngOnInit(): void {
    this._categories.getAllCategory().subscribe((data:any)=>{
      Swal.fire("Scussess !!","Success in Loadig data","success");
      this.description=data;
      // this.description=data;
      // success 
      // this.categories=data;
      // alert(this.description)

    },
  
    (error)=>{
      Swal.fire("Error !!","Error in Loadig data","error");
    }
  
  )
  }


  categories=[
    {
      cid:1,
      title:"programing",
      description:"this is testing categories"
    },
    {
      cid:2,
      title:"chemistry",
      description:"this is testing categories"
    },

    {
      cid:3,
      title:"sociology",
      description:"this is testing categories"
    },

    {
      cid:4,
      title:"physics",
      description:"this is testing categories"
    },

    {
      cid:5,
      title:"Drama",
      description:"this is testing categories"
    },

    {
      cid:6,
      title:"Culture",
      description:"this is testing categories"
    },

    {
      cid:7,
      title:"Phyloshopy",
      description:"this is testing categories"
    },

    {
      cid:8,
      title:"History",
      description:"this is testing categories"
    },
  ]
}
