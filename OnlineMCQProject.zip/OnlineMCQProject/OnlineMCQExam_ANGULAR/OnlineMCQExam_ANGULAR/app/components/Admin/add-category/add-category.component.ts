import { Component, OnInit } from '@angular/core';
import { AddCategory } from 'src/app/Models/add-category';
import { AddcategoryService } from 'src/app/services/addcategory.service';
import Swal from 'sweetalert2'
@Component({
  selector: 'app-add-category',
  templateUrl: './add-category.component.html',
  styleUrls: ['./add-category.component.css']
})
export class AddCategoryComponent implements OnInit {

  constructor(private add_categoryService:AddcategoryService) { }

  ngOnInit(): void {
  }

  desc_id:any
  title:any
  description:any

  allDescription:any
  addDescription:any
  saveCategory(){

    if(this.title == null || this.description ==null){
      return
    }

    // alert("hello")
    this.addDescription=new AddCategory(this.desc_id,this.title,this.description);
    this.add_categoryService.saveCategory(this.addDescription).subscribe((data)=>{
    
              
        Swal.fire({
          position: "center",
          icon: "success",
          title: "Your work has been saved",
          showConfirmButton: false,
          timer: 1500
        });
       },

    (error:any) => {
      // alert("error")
      Swal.fire("Error !!","Error in Loadig data","error");

    }
  );
  }
}


