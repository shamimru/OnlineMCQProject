import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-quiz-questions',
  templateUrl: './view-quiz-questions.component.html',
  styleUrls: ['./view-quiz-questions.component.css']
})
export class ViewQuizQuestionsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  questions:any

}
