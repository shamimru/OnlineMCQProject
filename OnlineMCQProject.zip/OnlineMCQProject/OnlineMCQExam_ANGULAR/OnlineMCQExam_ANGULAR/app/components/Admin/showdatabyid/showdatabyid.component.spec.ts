import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ShowdatabyidComponent } from './showdatabyid.component';

describe('ShowdatabyidComponent', () => {
  let component: ShowdatabyidComponent;
  let fixture: ComponentFixture<ShowdatabyidComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ShowdatabyidComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ShowdatabyidComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
