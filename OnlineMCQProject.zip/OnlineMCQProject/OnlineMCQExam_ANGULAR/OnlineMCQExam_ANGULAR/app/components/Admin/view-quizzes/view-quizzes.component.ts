import { Component, OnInit } from '@angular/core';
import { QuizzService } from 'src/app/services/quizz.service';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-view-quizzes',
  templateUrl: './view-quizzes.component.html',
  styleUrls: ['./view-quizzes.component.css']
})
export class ViewQuizzesComponent implements OnInit {

  constructor(
    private _myservice: UserService,
    private _myquizz:UserService

  ) { }

  ngOnInit(): void {

    this._myquizz.getAllQuizzes().subscribe((quizzes:any)=>{

      this.allQuizzes_from_database=quizzes
    })
  }

allQuizzes_from_database:any

 getallQuizzes(){
  this._myquizz.getAllQuizzes().subscribe((quizz:any)=>{
    this.allQuizzes_from_database=quizz;

    if(quizz !=null){
      alert("success")
    }else{
      alert("fail")
    }
  })
 }


  quizzes: any = [
    {
      qid: 1,
      title: "java",
      descrption: "Java is a high-level, general-purpose, object-oriented, and secure programming language",
      maxMarks: "50",
      numberOfQuestion: "20",
      Action: "true",
      category: {
        title: "programming"
      }
    },

    {
      qid: 2,
      title: "Python",
      descrption: "basic quistion",
      maxMarks: "50",
      numberOfQuestion: "20",
      Action: "true",
      category: {
        title: "programming"
      }
    },

    {
      qid: 3,
      title: "javaScript",
      descrption: "basic quistion",
      maxMarks: "50",
      numberOfQuestion: "20",
      Action: "true",
      category: {
        title: "programming"
      }
    },

    {
      qid: 1,
      title: "java",
      descrption: "basic quistion",
      maxMarks: "50",
      numberOfQuestion: "20",
      Action: "true",
      category: {
        title: "programming"
      }
    },

    {
      qid: 1,
      title: "java",
      descrption: "basic quistion",
      maxMarks: "50",
      numberOfQuestion: "20",
      Action: "true",
      category: {
        title: "programming"
      }
    }
  ]
}
