import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatButtonModule } from '@angular/material/button';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { MatInputModule } from '@angular/material/input';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { UserService } from './services/user.service';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatCardModule } from '@angular/material/card';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatIconModule } from '@angular/material/icon';
import { DashboardComponent } from './components/Admin/dashboard/dashboard.component';
import { MatListModule } from '@angular/material/list';
import { MatTableModule } from '@angular/material/table';
import { ViewCategoriesComponent } from './components/Admin/view-categories/view-categories.component';
import { AddCategoryComponent } from './components/Admin/add-category/add-category.component';
import { ProfileComponent } from './components/Admin/profile/profile.component';
import { SidebarComponent } from './components/Admin/sidebar/sidebar.component';
import { ShowdatabyidComponent } from './components/Admin/showdatabyid/showdatabyid.component';
import { NavbarComponent } from './components/pages/navbar/navbar.component';
import { FooterComponent } from './components/pages/footer/footer.component';
import { SigninComponent } from './components/pages/signin/signin.component';
import { SignupComponent } from './components/pages/signup/signup.component';
import { HomeComponent } from './components/pages/home/home.component';
import { SuccessComponent } from './components/pages/success/success.component';
import { WelcomeComponent } from './components/pages/welcome/welcome.component';
import { ViewQuizzesComponent } from './components/Admin/view-quizzes/view-quizzes.component';
import { AddcategoryService } from './services/addcategory.service';
import { CategorySeviceService } from './services/category-sevice.service';
import { AddQuizComponent } from './components/Admin/add-quiz/add-quiz.component';
import {MatSlideToggleModule} from '@angular/material/slide-toggle';
import {MatSelectModule} from '@angular/material/select';
import { ShowAllDataComponent } from './components/Admin/show-all-data/show-all-data.component';
import { EditRegisterDataComponent } from './components/Admin/edit-register-data/edit-register-data.component';
import { FailPageComponent } from './components/pages/fail-page/fail-page.component';
import { ViewQuizQuestionsComponent } from './components/Admin/view-quiz-questions/view-quiz-questions.component';
import {MatFormFieldModule} from '@angular/material/form-field'; 


@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    FooterComponent,
    SigninComponent,
    SignupComponent,
    HomeComponent,
    SuccessComponent,
    ProfileComponent,
    DashboardComponent,
    SidebarComponent,
    WelcomeComponent,
    ShowdatabyidComponent,
    ViewCategoriesComponent,
    AddCategoryComponent,
    ViewQuizzesComponent,
    AddQuizComponent,
    ShowAllDataComponent,
    EditRegisterDataComponent,
    FailPageComponent,
    ViewQuizQuestionsComponent
 ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MatButtonModule,
    MatInputModule,
    MatFormFieldModule,
    FormsModule,
    HttpClientModule,
    MatSnackBarModule,
    MatCardModule,
    MatToolbarModule,
    MatIconModule,
    MatListModule,
    MatTableModule,
    MatSlideToggleModule,
    MatSelectModule,
    NgbModule,

  ],
  providers: [UserService,AddcategoryService,CategorySeviceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
