import { TestBed } from '@angular/core/testing';

import { CategorySeviceService } from './category-sevice.service';

describe('CategorySeviceService', () => {
  let service: CategorySeviceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CategorySeviceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
