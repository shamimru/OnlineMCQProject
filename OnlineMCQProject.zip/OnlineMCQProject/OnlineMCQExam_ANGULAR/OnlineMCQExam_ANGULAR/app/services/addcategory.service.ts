import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { AddCategory } from '../Models/add-category';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AddcategoryService {

  constructor(private _http:HttpClient) { }



  url:any;
  saveCategory(r:AddCategory):Observable<AddCategory>{
    this.url="http://localhost:8080/savecategory"
    return this._http.post<AddCategory>(this.url,r);
  }

}
