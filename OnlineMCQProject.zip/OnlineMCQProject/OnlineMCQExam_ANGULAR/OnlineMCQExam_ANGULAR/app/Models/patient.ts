export class Patient {
  
    patient_id:any;
    name:any;
    gender:any;
    problem:any;
    phone:any;
    constructor(id:any,name:any,gender:any,problem:any,phone:any){
        this.patient_id=id;
        this.name=name;
        this.gender=gender;
        this.problem=problem;
        this.phone=phone;
    }

}
