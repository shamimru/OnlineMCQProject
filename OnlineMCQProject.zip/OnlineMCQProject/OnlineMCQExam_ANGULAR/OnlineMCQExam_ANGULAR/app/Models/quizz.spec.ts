import { Quizz } from './quizz';

describe('Quizz', () => {
  it('should create an instance', () => {
    expect(new Quizz()).toBeTruthy();
  });
});
