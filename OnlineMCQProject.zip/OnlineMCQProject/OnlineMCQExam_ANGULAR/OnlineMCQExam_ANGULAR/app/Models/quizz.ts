export class Quizz {

   quiz_id: any
   title: any
   description: any;
   max_marks: any;
   no_of_question: any;
   publish: any;
   category_id_fk: any;


  

   constructor(id: any, title: any, description: any, max_n: any, noOfQ: any, publish: any, category: any) {
      this.quiz_id = id;
      this.title = title;
      this.description = description;
      this.max_marks = max_n;
      this.no_of_question = noOfQ;
      this.publish = publish;
      this.category_id_fk = category;
   }
}
