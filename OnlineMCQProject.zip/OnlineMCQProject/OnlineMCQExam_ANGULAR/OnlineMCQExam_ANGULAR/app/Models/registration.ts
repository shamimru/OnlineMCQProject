export class Registration {

    registration_id:any;
    username:any;
    password:any;
    firstname:any;
    lastname:any;
    email:any;
    phone:any;

    constructor(registration_id:any,u:any,pass:any,fname:any,lname:any,email:any,phone:any){
        this.registration_id=registration_id;
        this.username=u;
        this.password=pass;
        this.firstname=fname;
        this.lastname=lname;
        this.email=email;
        this.phone=phone;
    }
}
