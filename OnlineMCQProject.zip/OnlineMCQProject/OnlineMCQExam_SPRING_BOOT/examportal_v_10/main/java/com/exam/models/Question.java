package com.exam.models;

public class Question {
	
	private long questionId;
	private int quiz_id;
	private String content;
	private String image;
	private String option_1;
	private String option_2;

	private String option_3;

	private String option_4;
	private String answer;
	
	
	public Question() {
		super();
	}


	public Question(long questionId, int quiz_id, String content, String image, String option_1, String option_2,
			String option_3, String option_4, String answer) {
		super();
		this.questionId = questionId;
		this.quiz_id = quiz_id;
		this.content = content;
		this.image = image;
		this.option_1 = option_1;
		this.option_2 = option_2;
		this.option_3 = option_3;
		this.option_4 = option_4;
		this.answer = answer;
	}


	public long getQuestionId() {
		return questionId;
	}


	public void setQuestionId(long questionId) {
		this.questionId = questionId;
	}


	public int getQuiz_id() {
		return quiz_id;
	}


	public void setQuiz_id(int quiz_id) {
		this.quiz_id = quiz_id;
	}


	public String getContent() {
		return content;
	}


	public void setContent(String content) {
		this.content = content;
	}


	public String getImage() {
		return image;
	}


	public void setImage(String image) {
		this.image = image;
	}


	public String getOption_1() {
		return option_1;
	}


	public void setOption_1(String option_1) {
		this.option_1 = option_1;
	}


	public String getOption_2() {
		return option_2;
	}


	public void setOption_2(String option_2) {
		this.option_2 = option_2;
	}


	public String getOption_3() {
		return option_3;
	}


	public void setOption_3(String option_3) {
		this.option_3 = option_3;
	}


	public String getOption_4() {
		return option_4;
	}


	public void setOption_4(String option_4) {
		this.option_4 = option_4;
	}


	public String getAnswer() {
		return answer;
	}


	public void setAnswer(String answer) {
		this.answer = answer;
	}


	@Override
	public String toString() {
		return "Question [questionId=" + questionId + ", quiz_id=" + quiz_id + ", content=" + content + ", image="
				+ image + ", option_1=" + option_1 + ", option_2=" + option_2 + ", option_3=" + option_3 + ", option_4="
				+ option_4 + ", answer=" + answer + "]";
	}


	
	
	
	
	
	

	


}
