package com.exam;

public class Patient {

	
	int patient_id;
	String name;
	String gender;
	String problem;
	String phone;
	
	public Patient() {
		// TODO Auto-generated constructor stub
	}

	public Patient(int patient_id, String name, String gender, String problem, String phone) {
		super();
		this.patient_id = patient_id;
		this.name = name;
		this.gender = gender;
		this.problem = problem;
		this.phone = phone;
	}

	public int getIdpatient_id() {
		return patient_id;
	}

	public void setIdpatient_id(int idpatient_id) {
		this.patient_id = idpatient_id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getProblem() {
		return problem;
	}

	public void setProblem(String problem) {
		this.problem = problem;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	@Override
	public String toString() {
		return "Patient [patient_id=" + patient_id + ", name=" + name + ", gender=" + gender + ", problem="
				+ problem + ", phone=" + phone + "]";
	}

	

	

	
	
}
